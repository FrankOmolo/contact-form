let currentIndex = 0;
const prevButton = document.getElementById('prevButton');
const nextButton = document.getElementById('nextButton');
const imageElement = document.getElementById('imageElement');

function updateImage() {
  imageElement.src = images[currentIndex];
}

prevButton.addEventListener('click', () => {
  currentIndex = (currentIndex === 0) ? images.length - 1 : currentIndex - 1;
  updateImage();
});

nextButton.addEventListener('click', () => {
  currentIndex = (currentIndex === images.length - 1) ? 0 : currentIndex + 1;
  updateImage();
});

function showSlide(index) {
  const slides = document.querySelector('.slides');
  const totalSlides = document.querySelectorAll('.slide').length;
  if (index >= totalSlides) {
    currentSlide = 0;
  } else if (index < 0) {
    currentSlide = totalSlides - 1;
  } else {
    currentSlide = index;
  }
  slides.style.transform = 'translateX(' + (-currentSlide * 100) + '%)';
}

function nextSlide() {
  showSlide(currentSlide);
}

function prevSlide() {
  showSlide(currentSlide - 1);
}